

#Create a list of highridge workers of at least 400 persons
#For reproducibility
set.seed(123)
workers <- data.frame(id = 1:400,
                      salary = sample(5000:35000, 400, replace = TRUE),
                      gender = sample(c("male", "female"),400, replace = TRUE))

#Generate payment slips
payment_slips <- data.frame()
for (i in 1:nrow(workers)){
  tryCatch({employee_level <- NA}
           if (workers$salary[i] > 10000 & workers$salary[i] < 20000) {employee_level <- "A1"}
           else if (workers$salary > 7500 & workers$salary[i] < 30000 & workers$gender[i] =="female") {employee_level <- "A5-F"}
           payment_slips <- rbind(payment_slips, data.frame(id = workers$id[i],
                                                            salary = workers$salary[i],
                                                            employee_level = employee_level)),
           error = function(e) {cat(paste("Error processing worker ID", workers$id[i], ":", e$message, "\n"))})}
#Output payment slips
print(payment_slips)
